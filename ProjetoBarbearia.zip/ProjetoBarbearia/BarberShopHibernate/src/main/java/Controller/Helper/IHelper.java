
package Controller.Helper;

//import static javafx.scene.input.KeyCode.T;


public interface IHelper {
    
    public abstract Object obterModelo();
        
    public abstract void limparTela();
    
    
}
